# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.pulseworkout'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "blogilates"
YOUTUBE_CHANNEL_ID_2 = "scooby1961"
YOUTUBE_CHANNEL_ID_3 = "JDCav24"
YOUTUBE_CHANNEL_ID_4 = "UCWN2FPlvg9r-LnUyepH9IaQ"
YOUTUBE_CHANNEL_ID_5 = "Gymra1"
YOUTUBE_CHANNEL_ID_6 = "popsugartvfit"
YOUTUBE_CHANNEL_ID_7 = "jessicasmithtv"
YOUTUBE_CHANNEL_ID_8 = "lovezumba"
YOUTUBE_CHANNEL_ID_9 = "saskiasdansschool"
YOUTUBE_CHANNEL_ID_10 = "TiffanyRotheWorkouts"
YOUTUBE_CHANNEL_ID_11 = "superherofitnesstv"
YOUTUBE_CHANNEL_ID_12 = "ZuzkaLight"
YOUTUBE_CHANNEL_ID_13 = "charliejames1975" 
YOUTUBE_CHANNEL_ID_14 = "WorkoutMusicService" 
YOUTUBE_CHANNEL_ID_15 = "yogawithadriene" 
YOUTUBE_CHANNEL_ID_16 = "womensworkouts" 
YOUTUBE_CHANNEL_ID_17 = "BeFit"
YOUTUBE_CHANNEL_ID_18 = "FitnessBlender"
YOUTUBE_CHANNEL_ID_19 = "joannasohofficial"
YOUTUBE_CHANNEL_ID_20 = "FitnesswithJessica"
YOUTUBE_CHANNEL_ID_21 = "KinoYoga"
YOUTUBE_CHANNEL_ID_22 = "livelovepartyTV"  

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Blogilates",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Scooby",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Athlean X",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Athlean X Woman",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Fitness Blender",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="BeFit",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Boho Beautiful",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GymRa",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Pop Sugar Fit",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Jessica Smith",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Zumba",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Saskias Dance School",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Tiffany Rothe Workouts",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Superhero Fitness TV",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Zuzka Light",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Body Rock",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Workout Music Service",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Yoga With Adriene",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="J Soh Fitness",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Fitness With Jessica",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Kino Yoga",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Live Love Party TV",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://image.spreadshirtmedia.com/image-server/v1/compositions/105003319/views/1,width=300,height=300,appearanceId=196,version=1440417743.jpg",
        folder=True )

run()